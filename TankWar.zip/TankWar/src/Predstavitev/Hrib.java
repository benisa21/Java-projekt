package Predstavitev;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

class Hrib extends JPanel {
    public Hrib() {
        super();
        setBackground(Color.WHITE);
    }
    @Override
    public void paint(Graphics g) {
        super.paint(g); // klic metode nadrazreda
        Graphics2D liki = (Graphics2D)g; // pretvarjanje tipov
        int zamik = 0; // pomožne spremenljivke

        liki.setColor(Color.BLACK);
        liki.fillArc(0,350, 500, 800, 0, 180);
        liki.drawArc(0, 350, 500, 800, 0, 180);	
        
        liki.fillArc(150,200, 1000, 1500, 0, 180);
        liki.drawArc(150, 200, 1000, 1500, 0, 180);	
        
        liki.fillRect(0, 400, 200, 400);
        liki.drawRect(0, 400, 200, 400);
        
        liki.fillRect(900, 300, 200, 400);
        liki.drawRect(900, 300, 200, 400);
        

    	       

    }
    	    
}
