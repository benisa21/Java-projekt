package objekti;

public class Zazeni extends tankWar {
	
//	static JFrame okno = new JFrame();
	private Okno okno;
	
	public Zazeni(int dolzina, int visina, int verzija) {
		super(dolzina, visina, verzija);
		okno = new Okno(this);
		okno.setVisible(true);
		this.dolzina = dolzina;
		}
	
	public Okno getOkno() {
		return okno;
	}
	
	@Override
	public void narisi() {
		okno.repaint();
	}
	
	@Override
	public void igraj() throws InterruptedException {
		narisi();
		while (true) {
//			this.premakni();
//			System.out.println(this.getPodlaga().getDolzina());
//			this.getPodlaga().getTank(2).premakni(dolzina, this.getPodlaga().getTeren_hrib(2));
			this.getPodlaga().getTank().premakni(dolzina, this.getPodlaga().getTeren_hrib());
			Thread.sleep(3);
			narisi();
//			System.out.println("neki");

			}

		}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int visina = 700;
		int dolzina = 1000;
		int verzija = 1;
		
//		int visina = 700;
//		int dolzina = 1000;
//		int verzija = 1;
		
//		Polozaj polozaj1 = new Polozaj(0,okno.getWidth(), 70, 45);
//		Polozaj polozaj2 = new Polozaj(900, 300, 70, 45);
//		Polozaj polozaj1 = new Polozaj(0,400-45, 70, 45);
		Zazeni zazeni1 = new Zazeni(dolzina, visina, verzija);
//		Zazeni zazeni2 = new Zazeni(polozaj2, false, false, 2);
//		System.out.println(zazeni1.getPodlaga().getDolzina());
		
		try {
			zazeni1.igraj();
//			zazeni2.igraj();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
	}
}
