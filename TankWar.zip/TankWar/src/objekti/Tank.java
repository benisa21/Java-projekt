package objekti;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Tank extends Objekt {
	
	private boolean premik_v_levo;
	private boolean premik_v_desno;
	
	private static final int MAX_ST_ZIVLJENJ = 5;
	
	private static final String SLIKA1 = "/Users/damijanrandl/Desktop/FMF/2_letnik/PROG2/Java/eclipse-workspace/TankWar/src/Predstavitev/tank.png";
	private static final String SLIKA2 = "/Users/damijanrandl/Desktop/FMF/2_letnik/PROG2/Java/eclipse-workspace/TankWar/src/Predstavitev/tank2.png";
	

	public Tank(Polozaj polozaj, boolean premik_v_levo, boolean premik_v_desno, int igralec) {
		super(polozaj, 0, SLIKA1, igralec);
		
		this.premik_v_levo = premik_v_levo;
		this.premik_v_desno = premik_v_desno;
		// TODO Auto-generated constructor stub
	}


	public boolean isPremik_v_levo() {
		return premik_v_levo;
	}


	public void setPremik_v_levo(boolean premik_v_levo) {
		this.premik_v_levo = premik_v_levo;
	}


	public boolean isPremik_v_desno() {
		return premik_v_desno;
	}


	public void setPremik_v_desno(boolean premik_v_desno) {
		this.premik_v_desno = premik_v_desno;
	}

	
	public File getFile() {
		if (this.getIgralec() == 1) {
			return new File(SLIKA1);
		}
		else {
			return new File(SLIKA2);
		}
	}
	
	public Polozaj getPresecisce(Teren_hrib hrib) {
//		int y = (int)(this.getPolozaj().getY()+this.getPolozaj().getVisina());
		int y = (int)(this.getPolozaj().getY() + this.getPolozaj().getVisina()/5);
		double a = hrib.getPolozaj().getDolzina()/2;
		double b = hrib.getPolozaj().getVisina()/2;
		
		int p = (int)(hrib.getPolozaj().getX() + a);
		int q = (int)(hrib.getPolozaj().getY() + b);
		
		int x1 = (int)(Math.sqrt((1- ((y-q)*(y-q))/(b*b)) * (a*a))+p);
		int x2 = (int)(-(Math.sqrt((1- ((y-q)*(y-q))/(b*b)) * (a*a)))+p);
		Polozaj polozaj1 = new Polozaj(x1, y, 0, 0);
		Polozaj polozaj2 = new Polozaj(x2, y, 0, 0);
		
		if (this.getIgralec() == 1) {
			return polozaj2;
		}
		else {
			return polozaj1;
			}
		
	}
	
	public void premakni(int dolzina, Teren_hrib hrib) {
		if (this.getPolozaj().getX() <= dolzina-this.getPolozaj().getDolzina() && this.getPolozaj().getX() >= 0) {
			if (this.getIgralec() == 1) {
				if (this.getPolozaj().getX() + this.getPolozaj().getDolzina() < getPresecisce(hrib).getX()) {
//					System.out.println(this.getPolozaj().getX());
//					System.out.println(getPresecisce(hrib).getX());
					
					if (this.premik_v_desno == true) {
						//			Polozaj nov_polozaj = new Polozaj(this.polozaj.getX() + 1, this.polozaj.getY(), this.polozaj.getDolzina(), this.polozaj.getVisina());
						this.getPolozaj().setX(this.getPolozaj().getX()+1);
					}
						
					if (this.premik_v_levo == true) {
						this.getPolozaj().setX(this.getPolozaj().getX()-1);
					}
				}
				
				else {
					this.getPolozaj().setX(this.getPolozaj().getX()-1);
				}
			}
			else {
				if (this.getPolozaj().getX() > getPresecisce(hrib).getX()) {
					
					if (this.premik_v_desno == true) {
						//			Polozaj nov_polozaj = new Polozaj(this.polozaj.getX() + 1, this.polozaj.getY(), this.polozaj.getDolzina(), this.polozaj.getVisina());
						this.getPolozaj().setX(this.getPolozaj().getX()+1);
					}
						
					if (this.premik_v_levo == true) {
						this.getPolozaj().setX(this.getPolozaj().getX()-1);
					}
				}
				else {
					this.getPolozaj().setX(this.getPolozaj().getX()+1);
				}
				
			}
				
		}
		else {
			if (this.getIgralec() == 1) {
				this.getPolozaj().setX(this.getPolozaj().getX()+1);
			}
			else {
				this.getPolozaj().setX(this.getPolozaj().getX()-1);
			}
		}

}
}

	
	
	
	