package objekti;

public class Teren_raven extends Objekt {

	public Teren_raven(Polozaj polozaj) {
		super(polozaj, 0, "", 0);
		// TODO Auto-generated constructor stub
	}

	

}
