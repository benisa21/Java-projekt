package objekti;

import java.util.HashMap;
import java.util.Map;

public class tankWar {
	
	protected static final int ZADETEK = 10;
	
	protected static final int USTRELJEN = -10;
	
	protected static final double VERJETNOST_ZADETKA = 0.5;
	
	private int st_iger;
	
	private Podlaga podlaga;
	
	private static Tank tank1;
	
	private Tank tank2;
	
	private Teren_hrib hrib;
	
	protected int dolzina;
	
	private Map<Tank, Integer> izid;
	
	
	
	public tankWar(int dolzina, int visina, int verzija) {
		st_iger = 0;
		
		podlaga = new Podlaga(dolzina, visina, 1, 1);
		
		izid = new HashMap<Tank, Integer>();
		
		this.dolzina = dolzina;
	
	
	}
	


	public void premakni(Tank tank) {
//		tank.premakni(dolzina, this.getPodlaga().getTeren_hrib(tank.getIgralec()));
		tank.premakni(dolzina, this.getPodlaga().getTeren_hrib());
	}
	
	public Podlaga getPodlaga() {
		return podlaga;
	}
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return podlaga.toString();
	}

	protected void narisi() {
		System.out.println(this);
	}
	
	public void igraj() throws InterruptedException {
		narisi();
		
		while (true) {
			narisi();
//			System.out.println("neki");
			
			Thread.sleep(20);
		}
	}
	
	
	public static void main(String[] args) {
//		int dolzina = args.length > 0? Integer.parseInt(args[0]): 1000;
//		int visina = args.length > 1? Integer.parseInt(args[1]): 700;
//		int verzija = 1;
		
		
		
//		Polozaj polozajTank1 = new Polozaj(0, 2*visina/3 - 45, 70, 45);
//		Polozaj polozajTank2 = new Polozaj(dolzina - 70, visina/2 - 45, 70, 45);
//		
		int visina = 700;
		int dolzina = 1000;
		
		tankWar tankWar = new tankWar(dolzina, visina, 1);
		
//		tank1 = tankWar.getPodlaga().getTank(1);
		tank1 = tankWar.getPodlaga().getTank();
////		
		Polozaj verzija_1_1 = new Polozaj(0,2*visina/3, dolzina/2, visina/3 +1);
		Polozaj verzija_1_2 = new Polozaj(dolzina/2, visina/2, dolzina/2, visina/2 +1);
//		
		Polozaj verzija_1_3 = new Polozaj(dolzina/8,3*visina/7, dolzina/2, 3*visina/2);
		Polozaj verzija_1_4 = new Polozaj(dolzina/3,2*visina/7, dolzina/2, 3*visina/2);
//		
		Teren_raven teren1 = new Teren_raven(verzija_1_1);
		Teren_raven teren2 = new Teren_raven(verzija_1_2);
//		
		Teren_hrib teren3 = new Teren_hrib(verzija_1_3, 0, 180);
		Teren_hrib teren4 = new Teren_hrib(verzija_1_4, 0, 180);
//		
		
		System.out.println(tank1.getPresecisce(teren3).getX());
		System.out.println(tank1.getPresecisce(teren3).getY());
		
//		try {
//			tankWar.igraj();
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
	}
}









