package objekti;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;

public class Podlaga {
	
	private int dolzina;
	private int visina;
	private List<Objekt> objekti;
	private Objekt objekt;
	private Tank tank1;
	private Tank tank2;
	private Teren_hrib teren3;
	private Teren_hrib teren4;
	private int igralec;
	

	public Podlaga(int dolzina, int visina, int verzija, int igralec) {
		if (dolzina <= 0 || visina <= 0 || verzija <= 0)
			throw new IllegalArgumentException();
		// TODO Auto-generated constructor stub
//		this.polozaj = polozaj;
		this.dolzina = dolzina;
		this.visina = visina;
		this.igralec = igralec;
		
		
		objekti = new ArrayList<Objekt>();
		
		Polozaj polozajTank1 = new Polozaj(0, 2*visina/3 - 45, 70, 45);
		Polozaj polozajTank2 = new Polozaj(dolzina - 70, visina/2 - 45, 70, 45);
		
		Polozaj verzija_1_1 = new Polozaj(0,2*visina/3, dolzina/2, visina/3 +1);
		Polozaj verzija_1_2 = new Polozaj(dolzina/2, visina/2, dolzina/2, visina/2 +1);
		
		Polozaj verzija_1_3 = new Polozaj(dolzina/8,3*visina/7, dolzina/2, 3*visina/2);
		Polozaj verzija_1_4 = new Polozaj(dolzina/3,2*visina/7, dolzina/2, 3*visina/2);
		
		Teren_raven teren1 = new Teren_raven(verzija_1_1);
		Teren_raven teren2 = new Teren_raven(verzija_1_2);
		
		teren3 = new Teren_hrib(verzija_1_3, 0, 180);
		teren4 = new Teren_hrib(verzija_1_4, 0, 180);
		
		tank1 = new Tank(polozajTank1, false, false, 1);
		tank2 = new Tank(polozajTank2, false, false, 2);
		
		objekti.add(tank1);
		objekti.add(tank2);
	
		objekti.add(teren1);
		objekti.add(teren2);
		
		objekti.add(teren3);
		objekti.add(teren4);
		
		
	}
	
	
		
	public int getIgralec() {
		return igralec;
	}



	public void setIgralec(int igralec) {
		this.igralec = igralec;
	}



	public int getDolzina() {
		return this.dolzina;
	}
	
	public int getVisina() {
		return this.visina;
	}
	public Tank getTank() {
		if (igralec == 1) {
			return tank1;
		}
		else {
			return tank2;
		}
	}

	
	public Teren_hrib getTeren_hrib() {
		if (igralec == 1) {
			return teren3;
		}
		else {
			return teren4;
		}
	}
	
	
	
	public Objekt getObjekt(Polozaj polozaj) {
		for (int i = 0; i < objekti.size();i++) {
			if (objekti.get(i).getPolozaj().isEnakPolozaj(polozaj)) {
				objekt = objekti.get(i);
			}
		}
		return objekt;
	}
	
	public void setObjekt(Objekt objekt) {
		objekti.add(objekt);
	}
	
	public List<Objekt> getObjekti() {
		return objekti;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String niz = "";
		for (int i = 0; i < objekti.size(); i++) {
			niz += objekti.get(i).toString() + "\n";
		}
		return niz;
	}


}
