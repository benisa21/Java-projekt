package objekti;

public class Objekt {
	
	private Polozaj polozaj;
	private int hitrost;
	private String slika;
	private int igralec;
	
	
	public Objekt(Polozaj polozaj, int hitrost, String slika, int igralec) {
		super();
		this.polozaj = polozaj;
		this.hitrost = hitrost;
		this.slika = slika;
		this.igralec = igralec;
	}

	public int getIgralec() {
		return igralec;
	}
	
	public void setIgralec(int igralec) {
		this.igralec = igralec;
	}


	public Polozaj getPolozaj() {
		return polozaj;
	}


	public void setPolozaj(Polozaj polozaj) {
		this.polozaj = polozaj;
	}


	public int getHitrost() {
		return hitrost;
	}


	public String getSlika() {
		return slika;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ""+this.getPolozaj().getX() +" , "+this.getPolozaj().getY() + " , " + this.getPolozaj().getDolzina() + " , " + this.getPolozaj().getVisina();
	}
	
	
}
