package objekti;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;

public class Okno extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Okno(Zazeni zazeni) {
		super();
		
		setSize(new Dimension(zazeni.getPodlaga().getDolzina(), zazeni.getPodlaga().getVisina()));
		setMinimumSize(new Dimension(800, 600));
		setResizable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		add(new IgralnoPolje(zazeni), BorderLayout.CENTER);
		
//		pack();
		
	}

}
