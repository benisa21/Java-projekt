package objekti;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class IgralnoPolje extends JPanel {
	
	private static final long serialVersionUID = 1L;

	
	private Zazeni zazeni;
	
	private Tank tank;
	
	private Teren_raven teren_raven;
	
	private Teren_hrib teren_hrib;
	
	private Objekt objekt_hrib;
	
	public IgralnoPolje(Zazeni zazeni) {
        super();
        
        
        setBackground(Color.GREEN);
        
        this.zazeni = zazeni;
        
        setFocusable(true);
		
		addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode()== KeyEvent.VK_RIGHT) {
					
//					zazeni.setPremik_v_desno(true);
//					zazeni.setPremik_v_levo(false);
//					zazeni.getPodlaga().getTank(2).setPremik_v_desno(true);
					zazeni.getPodlaga().getTank().setPremik_v_desno(true);
//					System.out.println(zazeni.getPodlaga().getTank(1));
					
				}
				else if (e.getKeyCode()==KeyEvent.VK_LEFT) {
//					for (int i = 0; i< zazeni.getPodlaga().getObjekti().size();i++) {
//						if (zazeni.getPodlaga().getObjekti().get(i) instanceof Tank) {
//							tank = (Tank)zazeni.getPodlaga().getObjekti().get(i);
//						}
//					}
//					zazeni.getPodlaga().getTank(2).setPremik_v_levo(true);
					zazeni.getPodlaga().getTank().setPremik_v_levo(true);
				}
				
				else if (e.getKeyCode()==KeyEvent.VK_SPACE) {
					if (zazeni.getPodlaga().getIgralec() == 1) {
						zazeni.getPodlaga().setIgralec(2);
					}
					else {
						zazeni.getPodlaga().setIgralec(1);
					}
				}
				zazeni.getOkno().repaint();
				
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode()== KeyEvent.VK_RIGHT) {
//					zazeni.getPodlaga().getTank(2).setPremik_v_desno(false);
					zazeni.getPodlaga().getTank().setPremik_v_desno(false);
				}
				else if (e.getKeyCode()==KeyEvent.VK_LEFT) {
//					zazeni.getPodlaga().getTank(2).setPremik_v_levo(false);
					zazeni.getPodlaga().getTank().setPremik_v_levo(false);
				}
				zazeni.getOkno().repaint();
			}
		
			
			
		});
	}
	
	

	Image slika1;
	Image slika2;


	@Override
    public void paint(Graphics g) {
        super.paint(g); // klic metode nadrazreda
        Graphics2D liki = (Graphics2D)g; // pretvarjanje tipov

        liki.setColor(Color.BLACK);
        
        double dolzina = (double)(getWidth())/(double)(zazeni.getPodlaga().getDolzina());
        double visina = (double)(getHeight())/(double)(zazeni.getPodlaga().getVisina());
        
  
        for (int i = 0; i< zazeni.getPodlaga().getObjekti().size();i++) {
        	
//        	System.out.println(zazeni.getPodlaga().getObjekti().get(i));
			if (zazeni.getPodlaga().getObjekti().get(i) instanceof Tank) {
				tank = (Tank)zazeni.getPodlaga().getObjekti().get(i);
				try {
					slika1 = ImageIO.read(tank.getFile());
//					slika2 = ImageIO.read(zazeni.getFile());
					
				} catch (IOException e) {
					System.err.println("Error loading tank");
					e.printStackTrace();
				}
				liki.drawImage(slika1, (int)Math.round((tank.getPolozaj().getX())*dolzina), (int)Math.round((tank.getPolozaj().getY())*visina), (int)Math.round((tank.getPolozaj().getDolzina())*dolzina),(int)Math.round((tank.getPolozaj().getVisina())*visina), null);

			}
			else if (zazeni.getPodlaga().getObjekti().get(i) instanceof Teren_raven) {
				teren_raven = (Teren_raven)zazeni.getPodlaga().getObjekti().get(i);
				liki.drawRect((int)Math.round(teren_raven.getPolozaj().getX()*dolzina), (int)Math.round((teren_raven.getPolozaj().getY())*visina), (int)Math.round(teren_raven.getPolozaj().getDolzina()*dolzina), (int)Math.round(teren_raven.getPolozaj().getVisina()*visina));
				liki.fillRect((int)Math.round(teren_raven.getPolozaj().getX()*dolzina), (int)Math.round((teren_raven.getPolozaj().getY())*visina), (int)Math.round(teren_raven.getPolozaj().getDolzina()*dolzina), (int)Math.round(teren_raven.getPolozaj().getVisina()*visina));
			}
//			
			else if (zazeni.getPodlaga().getObjekti().get(i) instanceof Teren_hrib) {
				objekt_hrib = zazeni.getPodlaga().getObjekti().get(i);
				teren_hrib = new Teren_hrib(objekt_hrib.getPolozaj(), 0, 180);
//				System.out.println(teren_hrib);
				liki.fillArc((int)Math.round((teren_hrib.getPolozaj().getX())*dolzina), (int)Math.round((teren_hrib.getPolozaj().getY())*visina), (int)Math.round((teren_hrib.getPolozaj().getDolzina())*dolzina), (int)Math.round((teren_hrib.getPolozaj().getVisina())*visina), (int)(teren_hrib.getZacetni_kot()), (int)(teren_hrib.getKoncni_kot()));
//				liki.drawArc((int)(teren_hrib.getPolozaj().getX()), (int)(teren_hrib.getPolozaj().getY()), teren_hrib.getPolozaj().getDolzina(), teren_hrib.getPolozaj().getVisina(), teren_hrib.getZacetni_kot(), teren_hrib.getKoncni_kot());
//				liki.fillArc((int)(teren_hrib.getPolozaj().getX()), (int)(teren_hrib.getPolozaj().getY()), teren_hrib.getPolozaj().getDolzina(), teren_hrib.getPolozaj().getVisina(), teren_hrib.getZacetni_kot(), teren_hrib.getKoncni_kot());
			}
			
		}

    }

}
