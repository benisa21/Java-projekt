package objekti;

public class Polozaj {
	public float x;
	public float y;
	public int dolzina;
	public int visina;
	
	public Polozaj(float x, float y, int dolzina, int visina) {
		super();
		this.x = x;
		this.y = y;
		this.dolzina = dolzina;
		this.visina = visina;
	}
	
	public Polozaj(Polozaj polozaj) {
		this.x = polozaj.x;
		this.y = polozaj.y;
		this.dolzina = polozaj.dolzina;
		this.visina = polozaj.visina;
		
	}
	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
	

	public void setX(float x) {
		this.x = x;
	}

	public void setY(float y) {
		this.y = y;
	}

	public void setDolzina(int dolzina) {
		this.dolzina = dolzina;
	}

	public void setVisina(int visina) {
		this.visina = visina;
	}

	public int getDolzina() {
		return dolzina;
	}

	public int getVisina() {
		return visina;
	}
	
	public boolean isEnakPolozaj(Polozaj polozaj) {
		if (this.getX() == polozaj.getX() && this.getY() == polozaj.getY() && this.getDolzina() == polozaj.getDolzina() && this.getVisina() == polozaj.getVisina()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Polozaj Premik(Polozaj polozaj) {
		return new Polozaj(this.x + polozaj.x, this.y + polozaj.y, this.dolzina, this.visina);
	}
	
	public boolean sePrekriva(Polozaj polozaj2) {
		return (Math.abs(this.x - polozaj2.x) <= this.dolzina && Math.abs(this.y - polozaj2.y) <= this.visina ||
				Math.abs(this.x - polozaj2.x) <= polozaj2.dolzina && Math.abs(this.y - polozaj2.y) <= polozaj2.visina);
	}
	
}
