package objekti;

import java.util.List;

public class Krogla extends Objekt {
	
	public int kot;
	private Polozaj cilj;
//	private List<Objekt> objekti;
	
	public Krogla (Polozaj polozaj, int hitrost, int kot, String slika, int igralec) {
		super(polozaj, hitrost, slika, igralec);
		this.kot = kot;
		
	}


	public int getKot() {
		return kot;
	}
	

	public void setKot(int kot) {
		this.kot = kot;
	}

	// hitrost razdelimo na x in y koordinato, da izracunamo pot oz lokacijo trka
	public int getHitrostX() {
		return (int)(this.getHitrost() * Math.cos(Math.toRadians(this.kot)));
	}
	
	public int getHitrostY() {
		return (int)(this.getHitrost() * Math.sin(Math.toRadians(this.kot)));
	}
	
	public Polozaj getCilj(List<Objekt> objekti) {
		for (int i = 0; i < objekti.size(); i++) {
			if (objekti.get(i).getPolozaj().sePrekriva(this.getPolozaj()) || this.getPolozaj().getX() < 0 || this.getPolozaj().getX() > 1024) {
				cilj = new Polozaj(this.getPolozaj());
			}
			}
		return cilj;
		}
		
	
}
