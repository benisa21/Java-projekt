package objekti;

public class Eksplozija extends Objekt {

	public Eksplozija(Polozaj polozaj, String slika) {
		super(polozaj, 0, slika, 1);
		// TODO Auto-generated constructor stub
	}
	
	
	public Polozaj getPolozajEksplozije(Krogla krogla) {
		return new Polozaj(krogla.getCilj(null));
	}

}
